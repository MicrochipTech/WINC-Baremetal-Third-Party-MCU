
To update the WINC1500 Firmware:

- make sure to run/flash SERIALBRIDGE application from the MCU.
- make sure to release the COM port
- run the update procedure from the batch file located into FIRMWARE_DOWNLOAD\Doc

